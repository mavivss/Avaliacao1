x=float(input("Informe quanto você ganha por aula: "))
y=int(input("Informe a quantidade de horas trabalhadas: "))

sb=(x*y)

inss=(sb*0.08)

sind=(sb*0.05)

ir=(sb*0.11)

sl=(sb-(ir+sind+inss))

imptotal=(ir+sind+inss)

print("Salário bruto: ", sb)
print("INSS: ", inss)
print("Imposto de renda: ", ir)
print("Sindicato: ", sind)
print("Salário líquido: ", sl)
print("Total de impostos: ", imptotal)

