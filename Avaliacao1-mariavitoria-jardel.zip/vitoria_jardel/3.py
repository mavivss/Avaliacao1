h=float(input('informe sua altura'))
x=str(input('informe seu sexo xom m pra mas e f pra fem'))

if x=='m':
    pesoideal=(72,7*h)-58
    print(pesoideal)

if x=='f':
    pesoideal=(62,1*h)-44,7
    print(pesoideal)
