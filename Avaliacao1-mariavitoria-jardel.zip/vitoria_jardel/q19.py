numero=float(input("Informe um número: "))
if numero>0:
    print("P")
elif numero<0:
    print("N")
elif numero==0:
    print("Z")
