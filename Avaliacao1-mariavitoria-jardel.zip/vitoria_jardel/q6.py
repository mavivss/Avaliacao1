turno=str(input("Informe o turno que você estuda. Digite M, V ou N: "))
if turno=="M":
    print("Bom dia!")

elif turno=="V":
    print("Boa tarde!")

elif turno=="N":
    print("Boa noite!")

else:
    print("Valor inválido!")
