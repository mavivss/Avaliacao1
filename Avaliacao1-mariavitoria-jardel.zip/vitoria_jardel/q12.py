x=1
q=0
while (x<=10):
  n1=float(input("informe a nota 1 do aluno: "))
  n2=float(input("informe a nota 2 do aluno: "))
  n3=float(input("informe a nota 3 do aluno: "))
  n4=float(input("informe a nota 4 do aluno: "))
  media=(n1+n2+n3+n4)/4
  med=[media]
  if media>=7.0:
    q=q+1
    x=x+1
    print(q)
