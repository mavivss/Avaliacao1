x=str(input("Informe o primeiro argumento: "))
y=str(input("Informe o segundo argumento: "))
z=str(input("Informe o terceiro argumento: "))
print("A soma dos argumentos é: ",x+y+z)
