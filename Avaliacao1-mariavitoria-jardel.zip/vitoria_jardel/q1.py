f=int(input("Digite a tempertura em farenheit:"))
c=(5*(f-32)/9)
print("A temperatura em celsius é %d"%(c))
