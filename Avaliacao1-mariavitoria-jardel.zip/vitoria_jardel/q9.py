kgmor=int(input("Quantidade em quilos de morango: "))
kgmaca=int(input("Quantidade em quilos de maçã: "))
if kgmor<=5:
    valormor=kgmor*2.5
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormor)

elif kgmor>5 or kgmor>6 or kgmor>7 or kgmor>=8:
    valormor=kgmor*2.2
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormor)

elif kgmor>8 or kgmor>11:
    valormor=(kgmor*2.2)*0.1
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormor)

if kgmaca<=5:
    valormaca=kgmaca*1.8
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)

elif kgmaca>5 or kgmaca>6 or kgmaca>7 or kgmaca>=8:
    valormaca=kgmaca*1.5
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)

elif kgmaca>8 or kgmaca>16:
    valormaca=(kgmaca*1.5)*0.1
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)
