sal=int(input("Informe seu salário: "))
if sal<=280:
    salatual=(sal*0.2)+sal
    print("Salário antes do reajuste: ", sal)
    print("Percentual de aumento aplicado: 20%")
    print("Valor do aumento: ",(sal*0.2))
    print("Novo salário depois do aumento: ", salatual)

elif sal>280 and sal<=700:
    salatual=(sal*0.15)+sal
    print("Salário antes do reajuste: ", sal)
    print("Percentual de aumento aplicado: 15%")
    print("Valor do aumento: ",(sal*0.15))
    print("Novo salário depois do aumento: ", salatual)

elif sal>700 and sal<=1500:
    salatual=(sal*0.10)+sal
    print("Salário antes do reajuste: ", sal)
    print("Percentual de aumento aplicado: 10%")
    print("Valor do aumento: ",(sal*0.10))
    print("Novo salário depois do aumento: ", salatual)

elif sal>1500:
    salatual=(sal*0.05)+sal
    print("Salário antes do reajuste: ", sal)
    print("Percentual de aumento aplicado: 5%")
    print("Valor do aumento: ",(sal*0.05))
    print("Novo salário depois do aumento: ", salatual)
    

