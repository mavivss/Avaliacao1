dia=int(input("Informe o dia: "))
ano= int(input("Informe o ano: "))
mes=int(input("Informe o mes: "))

x=0
meses=[" ","janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"]
for i in range(13):
    if dia>31 or dia<1:
        break
    elif mes>13 or mes<1:
        break
    elif i==mes:
        print(dia," de ",meses[i], " de ", ano )
        x=x+1


    
    


