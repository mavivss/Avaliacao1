numero=int
numero = (input("Informe um número: "))
print(n[::-1])
