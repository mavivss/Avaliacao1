x=0
resp=(input("Telefonou para a vítima? S/N "))
resp.lower()
if resp=="S":
    x=x+1

resp=(input("Esteve no local do crime? S/N "))
resp.lower()
if resp=="S":
    x=x+1
    
resp=(input("Mora perto da vítima? S/N "))
resp.lower()
if resp=="S":
    x=x+1

resp=(input("Devia para a vítima? S/N "))
resposta.lower()
if resp=="S":
    x=x+1

resp=(input("Já trabalhou com a vítima? S/N "))
resp.lower()
if resp=="S":
    x=x+1

if x==2:
    print("Suspeita")

elif x==3 or x==4:
    print("Cúmplice")

elif x==5:
    print("Assassino")

else:
    print("Inocente")
    
