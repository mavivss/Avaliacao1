h=float(input("informe sua altura em cm: "))
sexo=int(input("Informe seu sexo com 1 para feminino e 2 para masculino: "))

if sexo==1:
   mulher=((62.1*h) - 44.7)
   print("%.2f" %mulher)

elif sexo==2:
   homem=((72.7*h) - 58)
   print("%f.2f"%homem)
