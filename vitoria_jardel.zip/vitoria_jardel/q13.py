vende=[0,0,0,0,0,0,0,0,0]
cont=0
resp="S"
while resp=="S":
    sal=float(input("Informe seu salario R$: " ))
    if 200 < sal <299:
       vende[0]=vende[0]+1
    elif 300 < sal > 399:
       vende[1]=vende[1]+1
    elif 400 < sal > 499:
        vende[2]=vende[2]+1
    elif 500 < sal > 599:
        vende[3]=vende[3]+1
    elif 600 < sal > 699:
        vende[4]=vende[4]+1
    elif 700 < sal > 799:
        vende[5]=vende[5]+1
    elif 800 < sal > 899:
        vende[6]=vende[6]+1
    elif 900 < sal > 999:
        vende[7]=vende[7]+1
    elif sal >= 1000:
        vende[8]=vende[8]+1
    cont=cont+1
    resp = input("Continuar?(S ou N)")
    if resp == 'n':
        break
print(vende[1])
    
    
    
    
