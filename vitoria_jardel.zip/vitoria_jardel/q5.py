metros=float(input("Informe os metros quadrados a serem pintados: "))

litros=(metros/3)

latas=(litros/18)

total=(latas*80)

print ("Você usará",latas,"latas de tinta")
print ("O preco total é de: R$",total) 
