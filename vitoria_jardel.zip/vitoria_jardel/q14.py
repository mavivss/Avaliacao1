x=0
espvogal = "aeiou "
frase=str(input("Digite uma frase: "))
for i in frase:
    if i in espvogal:
        x=x+1
print(x)        
